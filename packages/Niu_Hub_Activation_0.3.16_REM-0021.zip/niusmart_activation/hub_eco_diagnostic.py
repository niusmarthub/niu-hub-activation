"""Install and read the ECO-WORTHY Modbus diagnostics for REM-0021."""

import hashlib
import os
import stat
import tempfile

import yaml
from pathlib import Path

PAYLOAD = Path("/usr/local/share/eco_worthy_sensor.py")
BASE_HASH = Path("/usr/local/share/eco_worthy_original.sha256")
MANIFEST = Path("/usr/local/share/eco_worthy_manifest.json")
ENTITY = "sensor.eco_worthy_registres_modbus"


def normalized(data):
    return data.replace(b"\r\n", b"\n")


def staged_file(directory, data, owner):
    fd, name = tempfile.mkstemp(prefix=".niu-eco-worthy-", dir=directory)
    path = Path(name)
    try:
        with os.fdopen(fd, "wb") as handle:
            os.fchown(handle.fileno(), owner.st_uid, owner.st_gid)
            os.fchmod(handle.fileno(), stat.S_IMODE(owner.st_mode))
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
    except BaseException:
        path.unlink(missing_ok=True)
        raise
    return path


def install_eco_diagnostics(root, *, payload=PAYLOAD, base_hash=BASE_HASH):
    target = root / "custom_components" / "eco_worthy" / "sensor.py"
    if target.is_symlink():
        return "different_version"
    try:
        original = target.read_bytes()
    except FileNotFoundError:
        return "missing"
    replacement = payload.read_bytes()
    if normalized(original) == normalized(replacement):
        return "installed"
    if hashlib.sha256(normalized(original)).hexdigest() != base_hash.read_text().strip():
        return "different_version"

    metadata = target.stat()
    backup = target.with_name("sensor.py.niu-before-registers")
    if not backup.exists():
        saved = staged_file(target.parent, original, metadata)
        try:
            os.link(saved, backup)
        except FileExistsError:
            pass
        finally:
            saved.unlink(missing_ok=True)
    if backup.is_symlink() or normalized(backup.read_bytes()) != normalized(original):
        return "backup_conflict"

    candidate = staged_file(target.parent, replacement, metadata)
    try:
        if target.is_symlink() or target.read_bytes() != original:
            return "different_version"
        candidate.replace(target)
    finally:
        candidate.unlink(missing_ok=True)
    return "installed"



def configure_solar_platform(source):
    """Add the YAML platform to a local block sequence while preserving other YAML."""
    doc = yaml.compose(source)
    if not isinstance(doc, yaml.MappingNode) or doc.flow_style:
        return None
    sections = [value for key, value in doc.value
                if isinstance(key, yaml.ScalarNode) and key.value == "sensor"]
    newline = "\r\n" if "\r\n" in source else "\n"
    if not sections:
        return source + ("" if source.endswith(newline) else newline) + newline.join(
            ("", "sensor:", "  - platform: eco_worthy", "")
        )
    if len(sections) != 1:
        return None
    sensors = sections[0]
    if not isinstance(sensors, yaml.SequenceNode) or sensors.flow_style or not sensors.value:
        return None
    if any(isinstance(entry, yaml.MappingNode) and any(
        isinstance(k, yaml.ScalarNode) and k.value == "platform"
        and isinstance(v, yaml.ScalarNode) and v.value == "eco_worthy" for k, v in entry.value
    ) for entry in sensors.value):
        return source
    index = sensors.start_mark.index
    indent = " " * sensors.start_mark.column
    return source[:index] + "- platform: eco_worthy" + newline + indent + source[index:]


def bootstrap_eco_integration(root, *, payload=PAYLOAD, manifest=MANIFEST):
    """Provision a fresh component and configure its YAML platform if supported."""
    config = root / "configuration.yaml"
    if config.is_symlink() or not config.is_file():
        return "configuration_required"
    original = config.read_bytes()
    text = original.decode("utf-8")
    updated = configure_solar_platform(text)
    if updated is None:
        return "configuration_required"
    yaml.compose(updated)
    target = root / "custom_components" / "eco_worthy"
    if target.is_symlink():
        return "different_version"
    if not target.exists():
        target.parent.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(dir=target.parent) as temporary:
            component = Path(temporary) / "eco_worthy"
            component.mkdir()
            (component / "__init__.py").write_text('"""ECO-WORTHY MPPT integration."""\n')
            (component / "manifest.json").write_bytes(manifest.read_bytes())
            (component / "sensor.py").write_bytes(payload.read_bytes())
            component.rename(target)
    elif not (target / "manifest.json").is_file() or not (target / "sensor.py").is_file():
        return "different_version"

    if updated != text:
        backup = config.with_name("configuration.yaml.niu-before-eco-worthy")
        metadata = config.stat()
        if not backup.exists():
            saved = staged_file(root, original, metadata)
            try:
                os.link(saved, backup)
            except FileExistsError:
                pass
            finally:
                saved.unlink(missing_ok=True)
        candidate = staged_file(root, updated.encode("utf-8"), metadata)
        try:
            if config.is_symlink() or config.read_bytes() != original:
                return "configuration_required"
            candidate.replace(config)
        finally:
            candidate.unlink(missing_ok=True)
    return "installed"


def diagnostic_rows(states):
    """Return only the two complete, numbered blocks from the diagnostic sensor."""
    for state in states:
        entity_id = state.get("entity_id", "")
        if entity_id != ENTITY and not (
            entity_id.startswith(f"{ENTITY}_") and entity_id[len(ENTITY) + 1:].isdigit()
        ):
            continue
        registers = state.get("attributes", {}).get("registres")
        if state.get("state") in ("unavailable", "unknown") or not isinstance(registers, list):
            continue
        if len(registers) != 30:
            continue

        rows = []
        for idx, row in enumerate(registers):
            block = "L01" if idx < 15 else "L02"
            address = f"0x{idx if idx < 15 else 0x0401 + idx - 15:04X}"
            value = row.get("decimale") if isinstance(row, dict) else None
            if (type(value) is not int or not 0 <= value <= 0xffff
                    or row.get("numero") != idx + 1 or row.get("adresse") != address):
                break
            note = row.get("repere")
            rows.append({
                "numero": idx + 1,
                "bloc": block,
                "adresse": address,
                "decimale": value,
                "hexadecimale": f"0x{value:04X}",
                "repere": note[:100] if isinstance(note, str) else "Non identifié",
            })
        if len(rows) == 30:
            return rows
    return []
