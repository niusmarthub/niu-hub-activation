# Niu Hub Activation — pilote REM-0021

Ce paquet pilote contient l’add-on Home Assistant et des tests Python. Les endpoints PHP existants ne font pas partie de cette mise à jour.

## Modifications
- Activation : le Hub envoie **uniquement le code d'activation**. NiuSmart genere/attribue `hub_identifier`, retrouve le site, et renvoie la cle API, l'identite et les options. Le PHP rejette les codes expires, inconnus et deja `redeemed`.
- Synchronisation : lit `/homeassistant/niusmart/hub_config.json` et met à jour les options dans `site_config`. Les anciens fichiers restent lisibles.
- Archivage : avant remplacement, copie binaire verifiee dans `/homeassistant/niusmart/archive/hub_hub_config.json` (une seule archive tournante). **L'archive manuelle n'est jamais modifiee.**
- Rotation : `key-update.php` conserve les etapes check/commit/ack. La rotation n'est pas une synchronisation ordinaire.
- Le site 1 est refusé pendant le pilote.
- Une fois le hub activé, le Supervisor détecte et démarre NetBird. Pour une installation neuve, Niu Hub utilise la clé fournie à l’activation, celle de la section `netbird` ou l’option `netbird_setup_key` de l’add-on. L’option `netbird_repository` permet de choisir le dépôt. Le démarrage du client et sa connexion au réseau NetBird sont deux états distincts.
- Le tableau de bord affiche les options NiuSmart et les datapoints reçus ou lus localement. Le suivi de l’énergie publie les mesures de tous les modules dont la description indique un statut électrique, une unité et une échelle. Le profil PJ1103B fournit ces informations lorsqu’elles manquent pour ce produit. NiuSmart associe ensuite les statuts aux fonctions du site.

## 0.3.16 — options et diagnostic REM-0021

- Installez ou mettez à jour Niu Hub Activation. L’application réutilise le service MQTT fourni par le Supervisor et peut demander l’installation de Mosquitto si aucun service ni aucune configuration MQTT existante n’est détecté.
- L’option solaire NiuSmart prépare ECO-WORTHY et active la section solaire. Sur REM-0021, l’installation du diagnostic sauvegarde automatiquement le fichier d’origine reconnu. Une intégration installée ou mise à jour prend effet au prochain redémarrage de Home Assistant. Un fichier personnalisé différent déclenche un message dans Niu Hub et reste en place.
- Sous **Solaire ECO-WORTHY → Registres Modbus**, le tableau reçoit les 30 valeurs brutes de la dernière lecture valide. Les numéros 01–15 correspondent à L01 et 16–30 à L02. Il n’est pas nécessaire de créer une carte Home Assistant.
- Le nombre de climatiseurs NiuSmart prépare Niu CAN et définit les zones exportées en MQTT. Niu Hub tente de créer l’entrée Niu CAN dès que Home Assistant la reconnaît. Les commandes Dometic passent par les thermostats Niu CAN de Home Assistant.
- La désactivation retire les annonces MQTT créées par Niu Hub pour l’option. Une réduction de deux climatiseurs à un retire R2. La réactivation republie les entités correspondantes. Les états de ces sections sont publiés sans rétention.
- Ce paquet est prévu pour le pilote REM-0021. Le provisionnement du Supervisor, le redémarrage et les lectures matérielles restent à confirmer sur le hub.

## 0.3.15 — pilote REM-0021

- Regroupement automatique des 32 entrées NDIH-432, avec sauvegarde du YAML et rechargement MQTT.
- Niu CAN est fourni pour la climatisation. Si une intégration est déjà en place, elle est utilisée telle quelle.
- Le pont MQTT solaire lit les capteurs de l’intégration Bluetooth ECO-WORTHY de Home Assistant. La vue de l’add-on affiche neuf champs pour le panneau, la batterie et la sortie LOAD. Un champ sans mesure identifiable reste indisponible. Une puissance calculée à partir de la tension et du courant est signalée comme telle. Les énergies cumulées proviennent uniquement des compteurs exposés par l’intégration.
- Les relais Tuya sont numérotés par module, sans modifier leurs sujets MQTT de commande. Leur ordre initial vient de l’inventaire NiuSmart. Un retrait définitif peut décaler les numéros d’affichage suivants.
- État du pilote : vérifier sur REM-0021 la disponibilité des états Bluetooth, la publication MQTT et les commandes des appareils physiques avant un déploiement plus large.

## 0.3.14 — commande locale des relais Tuya

- Tous les DP de relais reconnus (`switch`, `switch_N`, `relay`, `relay_N`) des modules détectés sont annoncés à Home Assistant comme des interrupteurs MQTT. Les anciens capteurs MQTT correspondants sont retirés.
- Une commande marche/arrêt est exécutée sur le réseau local avec TinyTuya. L’état affiché provient de la lecture réelle du relais. Un relais qui ne répond plus apparaît indisponible.
- Le tableau des modules affiche l’adresse IP, la disponibilité de la lecture et, pour chaque DP publié, son nom MQTT et son mode de commande.
- Après installation sur le REM-0021, vérifier que les relais apparaissent dans l’intégration MQTT, puis basculer un relais d’essai et vérifier que l’interrupteur et le relais physique changent d’état dans les deux sens.

## 0.3.13 — validation sur REM-0021

- Au démarrage ou avec **Redécouvrir les modules**, le hub récupère l’inventaire NiuSmart et cherche les modules autorisés sur le réseau local. Les options NiuSmart sont aussi vérifiées une fois par heure par défaut.
- Le hub vise une lecture locale par seconde et publie les changements dans MQTT. Après une première synchronisation réussie, il peut utiliser l’inventaire enregistré pendant une coupure Internet.
- Sur le PJ1103B, Home Assistant reçoit une précision d’une décimale pour les puissances en watts. Le sens du courant indique « Inconnu » si la lecture du compteur est disponible sans la valeur de direction. L’ancienne entité de test du DP 101 est retirée du broker.
- Les états Tuya sont publiés en lecture seule. La commande des relais depuis NiuSmart et la migration des scripts Dometic CAN restent à valider.

## IMPORTANT avant installation
1. Conserver la sauvegarde manuelle originale `/config/niusmart/archive/hub_config_avant_0.3.1_20261013.json` hors de portee de l'add-on.
2. Sur un Hub deja active, ne **pas** relancer l'activation : utiliser la synchronisation avec l'identite deja enregistree.
3. Sur un hub neuf, saisir le code d’activation. Si le fichier est absent, l’add-on le crée à partir de la réponse validée du serveur. Un ancien modèle compatible peut aussi être utilisé.
4. Verifier que le montage HA `/homeassistant` est reellement disponible en lecture/ecriture pour l'add-on; si absent, NE PAS installer pour ecriture.
5. Deployer `hub-activation.php` et l'add-on comme un ensemble coherent, seulement apres sauvegarde et verification de la version PHP. Ne pas deployer `key-update.php` si la version deja installee est identique.
6. Les tests fournis sont locaux et simules. Ils ne valident pas la base MySQL reelle, le reseau, le montage HA OS ou les integrations tierces.

## Limites connues
- Changement de serveur : non implemente, doit rester interdit.
- Recuperation automatique : non operationnelle sans endpoint PHP `recover`.
- L’activation reste limitée au site pilote. Les datapoints candidats au contrôle de relais sont signalés pour validation.
- Un Hub ancien sans identifiant `hub.hub_identifier` utilise son ancien identifiant persistant dans `/data/hub_identifier`.
- Pas de modification des secrets des integrations tierces par la synchronisation.

## Tests hors Hub
`python -m unittest discover -s . -p 'test_*.py' -v`
`php -l hub-activation.php`
`php -l key-update.php`
